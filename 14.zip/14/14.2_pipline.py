#10.2_pipline.py
import os
from first import *
from second import *
os.system(cmd1)
os.system(cdm2)